public class MotorWorkshop {
    public void changeTyre(Motor motor, Tyre tyre) {
        motor.setTyre(tyre);
        // Melakukan penggantian tyre pada motor
    }

    public void changeEngine(Motor motor, Engine engine) {
        motor.setEngine(engine);
        // Melakukan penggantian engine pada motor
    }
}
