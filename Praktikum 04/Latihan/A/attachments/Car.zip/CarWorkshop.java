public class CarWorkshop {
    public void changeTyre(Car car, Tyre tyre) {
		car.setTyre(tyre);
        // Mengganti ban mobil
    }

    public void changeEngine(Car car, Engine engine) {
		car.setEngine(engine);
        // Mengganti mesin mobil
    }
}
